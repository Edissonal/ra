import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consultas-ra',
  templateUrl: './consultas-ra.component.html',
  styleUrls: ['./consultas-ra.component.scss']
})
export class ConsultasRaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
