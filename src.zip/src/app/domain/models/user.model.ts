export interface User {
    id?:number;
    password?: string;
    user?:string;
    opt?:number
  }